package ru.evsmanko.mankoff.service;

public interface BuckovskyService {
    String creditSum(long id);
}
