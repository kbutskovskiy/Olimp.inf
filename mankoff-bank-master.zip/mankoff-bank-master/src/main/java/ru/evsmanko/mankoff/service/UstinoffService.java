package ru.evsmanko.mankoff.service;

public interface UstinoffService {
     String exportToJson(long id);
}
