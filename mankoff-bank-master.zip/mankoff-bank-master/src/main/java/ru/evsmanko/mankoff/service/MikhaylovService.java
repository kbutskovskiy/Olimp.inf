package ru.evsmanko.mankoff.service;

public interface MikhaylovService {
    String debitRemains();
}