package ru.evsmanko.mankoff.service;

public interface KozloffService {

    void test();
}
